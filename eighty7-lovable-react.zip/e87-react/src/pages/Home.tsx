import { useState } from "react";
import { Link } from "react-router-dom";
import CTASection from "../components/CTASection";

const WORK_TILES = [
  { tag: "Executive Presence", title: "Thought leadership & interviews", img: "work-1-executive-B7pM4FkU.webp" },
  { tag: "Customer Stories", title: "Testimonials & success features", img: "work-2-testimonial-BTlnWCDt.webp" },
  { tag: "Events & Keynotes", title: "Higher-caliber event coverage", img: "work-3-event-Dx4knwSK.webp" },
  { tag: "Product & Demo", title: "Cinematic product storytelling", img: "work-2-testimonial-BTlnWCDt.webp" },
  { tag: "Brand & Culture", title: "Company narrative films", img: "work-1-executive-B7pM4FkU.webp" },
  { tag: "Internal & Training", title: "Onboarding & internal comms", img: "work-3-event-Dx4knwSK.webp" },
];

const SERVICES = [
  { num: "01", title: "Video Testimonials", desc: "Real clients sharing real outcomes. No scripts, no fake energy — authentic stories that build credibility and close deals." },
  { num: "02", title: "Executive Interviews", desc: "Position your leadership team as category authorities, built for LinkedIn, your site, and beyond." },
  { num: "03", title: "Product Demos & Reviews", desc: "Turn complex features into clear, compelling stories that move buyers to act." },
  { num: "04", title: "Showcases", desc: "Case study films and brand anthems built to signal premium." },
  { num: "05", title: "Corporate Events", desc: "Higher-caliber coverage for conferences, summits, and corporate events." },
  { num: "06", title: "Training & Internal Comms", desc: "Onboarding and training videos that align teams and scale culture." },
];

const PROCESS_STEPS = [
  { step: "Step 01", title: "Discovery", desc: "A working conversation to learn the brand, the audience, and define what success looks like." },
  { step: "Step 02", title: "Proposal & Quote", desc: "A clear scope, creative direction, and value-based investment — no padded packages." },
  { step: "Step 03", title: "Agreement", desc: "We align on deliverables and timeline, then lock the project in." },
  { step: "Step 04", title: "Pre-Production", desc: "Concepting, scripting, location, casting, and logistics mapped before we roll." },
  { step: "Step 05", title: "Production", desc: "Cameras roll. Cinematic capture, calm set, every frame intentional." },
  { step: "Step 06", title: "Post-Production", desc: "Edit, color, sound, and final delivery — polished files built to perform." },
];

const FAQS = [
  { q: "What does a typical project cost?", a: "Projects typically start at $5,000 and go up to $100,000+, depending on scope, format, and deliverables. Fill out our contact form to schedule a free 30-minute discovery call." },
  { q: "Do you offer retainers?", a: "Yes, and they're one of the best ways to work with us. A retainer gives you a dedicated creative partner, priority on the calendar, consistent on-brand output, and preferred pricing." },
  { q: "How long does a project take?", a: "Final delivery is typically 2–3 weeks from the final shoot date. Expedited turnarounds are available for an additional fee." },
  { q: "What kind of clients do you work with?", a: "We primarily partner with B2B businesses, but we're open to any brand looking to elevate their marketing with cinematic, story-driven video." },
  { q: "How far do you travel? Do you charge a travel fee?", a: "We travel anywhere in the world. Projects within 75 miles of DFW include travel at no additional cost. Anything beyond is quoted transparently as a travel line item." },
  { q: "What's the best way to get started?", a: "Fill out our contact form and we'll schedule a 30-minute discovery call to learn about your brand and goals. From there we'll put together a tailored proposal." },
];

function FAQItem({ q, a, defaultOpen = false }: { q: string; a: string; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-[#0B1E3D]/12">
      <button
        className="flex justify-between items-center w-full py-6 gap-5 text-left"
        onClick={() => setOpen(!open)}
      >
        <h3 className="text-base font-bold text-[#0B1E3D] leading-snug">{q}</h3>
        <span className={`w-7 h-7 flex-shrink-0 rounded-full border-[1.5px] border-[#0B1E3D]/20 flex items-center justify-center text-lg text-[#0B1E3D] transition-transform duration-300 ${open ? "rotate-45" : ""}`}>+</span>
      </button>
      <div className={`overflow-hidden transition-all duration-400 ${open ? "max-h-80" : "max-h-0"}`}>
        <p className="pb-6 text-[15px] text-[#0B1E3D]/65 leading-relaxed">{a}</p>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <>
      {/* HERO */}
      <section
        className="min-h-[92vh] flex flex-col justify-center items-center text-center px-6 pt-24 pb-20"
        style={{
          background: "linear-gradient(rgba(11,30,61,0.82),rgba(11,30,61,0.88)), url('https://eighty7.media/assets/josh-ramsey-DsFRosA_.webp') center/cover no-repeat",
        }}
      >
        <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-5">
          B2B Video Production · McKinney, TX
        </p>
        <h1 className="text-white font-extrabold text-4xl md:text-6xl max-w-3xl mx-auto leading-tight mb-2">
          Eighty7 Media: Stories that build trust.
        </h1>
        <h1 className="text-[#B8892A] font-extrabold text-4xl md:text-6xl max-w-3xl mx-auto leading-tight mb-5">
          Videos that close deals.
        </h1>
        <p className="text-white/65 text-lg max-w-xl mx-auto leading-relaxed mb-9">
          Eighty7 Media is a McKinney-based B2B video production company helping businesses build trust through testimonial videos, executive interviews, brand films, and product storytelling.
        </p>
        <div className="flex gap-3.5 justify-center flex-wrap">
          <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
            Start a Project →
          </Link>
          <Link to="/work" className="inline-flex items-center gap-2 border-[1.5px] border-white/35 hover:border-white text-white text-[13px] font-semibold tracking-[0.05em] uppercase px-6 py-3 rounded transition-colors">
            ◁ View Our Work
          </Link>
        </div>
      </section>

      {/* IN GOOD COMPANY */}
      <section className="bg-white py-16 px-6">
        <div className="max-w-[1120px] mx-auto text-center">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3.5">In Good Company</p>
          <h2 className="text-[#0B1E3D] font-extrabold text-2xl mb-10">Built on the trust of leaders who don't settle</h2>
          <div className="flex items-center justify-center gap-10 flex-wrap">
            {[
              "dribbleup-B5vt8FfP.png",
              "growvana-B1jl8G0E.png",
              "stack-E5jzd4-n.png",
              "true-Bfeaq1YK.webp",
              "above-all-things-CFzhzR5Q.png",
              "rebelution-BBlsBG-8.png",
            ].map((img) => (
              <img
                key={img}
                src={`https://eighty7.media/assets/${img}`}
                alt=""
                className="h-7 opacity-40 grayscale hover:opacity-70 transition-opacity"
              />
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED WORK */}
      <section className="bg-[#142040] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">Featured Work</p>
              <h2 className="text-white font-extrabold text-3xl md:text-4xl">Where serious brands look their best.</h2>
            </div>
            <Link to="/work" className="text-[13px] font-bold tracking-[0.08em] uppercase text-[#B8892A] border-b border-[#B8892A] pb-0.5 hidden md:block">
              See All Work →
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {WORK_TILES.map(({ tag, title, img }) => (
              <div key={tag} className="relative bg-[#1a2d55] rounded overflow-hidden cursor-pointer group">
                <img
                  src={`https://eighty7.media/assets/${img}`}
                  alt={tag}
                  className="w-full aspect-[16/10] object-cover opacity-60 group-hover:opacity-75 transition-opacity"
                />
                {/* Play button */}
                <div className="absolute top-3 right-3 w-[34px] h-[34px] bg-white/15 rounded-full flex items-center justify-center">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><polygon points="5 3 19 12 5 21 5 3" /></svg>
                </div>
                {/* Gradient + text */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#1a2d55] to-transparent pt-10 px-[18px] pb-5">
                  <p className="text-[10px] font-bold tracking-[0.12em] uppercase text-[#B8892A] mb-1.5">{tag}</p>
                  <h4 className="text-white font-bold text-base leading-snug">{title}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHAT WE DO */}
      <section className="bg-[#F5F4F1] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">What We Do</p>
              <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl">Strategic video, built for business outcomes.</h2>
            </div>
            <Link to="/services" className="text-[13px] font-bold tracking-[0.08em] uppercase text-[#B8892A] border-b border-[#B8892A] pb-0.5 hidden md:block">
              All Services →
            </Link>
          </div>
          <ul className="border-t border-[#0B1E3D]/10">
            {SERVICES.map(({ num, title, desc }) => (
              <li key={num} className="grid grid-cols-[56px_1fr_auto] items-start gap-5 py-6 border-b border-[#0B1E3D]/10">
                <span className="text-[12px] font-bold text-[#B8892A] tracking-[0.05em] pt-1">{num}</span>
                <div>
                  <h3 className="text-[#0B1E3D] font-extrabold text-[1.1rem] mb-1.5">{title}</h3>
                  <p className="text-[14px] text-[#0B1E3D]/65 leading-relaxed max-w-xl">{desc}</p>
                </div>
                <span className="text-xl text-[#0B1E3D]/25 pt-1">↗</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* PROCESS */}
      <section className="bg-white py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <div className="max-w-[640px] mb-12">
            <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">Our Video Production Process</p>
            <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl mb-4">A clear path from idea to delivery.</h2>
            <p className="text-[#0B1E3D]/60 text-base leading-relaxed">Every engagement follows the same purposeful framework, built for B2B leaders who expect strategy, clarity, and craft at every step.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {PROCESS_STEPS.map(({ step, title, desc }) => (
              <div key={step} className="p-7 border-[1.5px] border-[#0B1E3D]/10 rounded">
                <p className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">{step}</p>
                <h4 className="text-[#0B1E3D] font-extrabold text-base mb-2">{title}</h4>
                <p className="text-sm text-[#0B1E3D]/60 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
            Start Your Project →
          </Link>
        </div>
      </section>

      {/* WHY EIGHTY7 */}
      <section className="bg-[#142040] py-22 px-6">
        <div className="max-w-[1120px] mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Why Eighty7 Media</p>
            <h2 className="text-white font-extrabold text-3xl md:text-[2.6rem] leading-tight mb-1">We think before we shoot.</h2>
            <h2 className="text-[#B8892A] font-extrabold text-3xl md:text-[2.6rem] leading-tight mb-5">Every frame serves a purpose.</h2>
            <p className="text-white/65 text-base leading-relaxed">We're the creative partner for founders, CEOs, and CMOs who understand that great video is a business asset, not a line item.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { title: "Strategic", desc: "Frames that serve objectives." },
              { title: "Cinematic", desc: "Looks ten times more expensive." },
              { title: "Human", desc: "Real people. No fake energy." },
              { title: "Proven", desc: "Trusted by enterprise brands." },
            ].map(({ title, desc }) => (
              <div key={title} className="p-6 border border-white/10 rounded">
                <h4 className="text-white font-extrabold text-[15px] mb-1.5">{title}</h4>
                <p className="text-sm text-white/55 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-[#F5F4F1] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <div className="max-w-[640px] mx-auto text-center mb-10">
            <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">Frequently Asked</p>
            <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl">We're here to answer every question.</h2>
          </div>
          <div className="max-w-[760px] mx-auto">
            {FAQS.map((item, i) => <FAQItem key={i} q={item.q} a={item.a} defaultOpen={i === 0} />)}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
