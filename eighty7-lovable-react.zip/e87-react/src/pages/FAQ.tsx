import { useState } from "react";
import CTASection from "../components/CTASection";
import { Link } from "react-router-dom";

const FAQS = [
  { q: "What does a typical project cost?", a: "Projects typically start at $5,000 and go up to $100,000+, depending on scope-of-work, format, and amount of deliverables. Fill out our contact form to schedule a free 30-minute discovery call where we'll learn about your goals and walk through pricing options together." },
  { q: "Do you offer retainers?", a: "Yes, and they're one of the best ways to work with us. A retainer gives you a dedicated creative partner, priority on the production calendar, consistent on-brand output every month, and preferred pricing across the engagement." },
  { q: "How long does a project take?", a: "Timelines vary by project, but final delivery is typically 2–3 weeks from the final shoot date. Expedited turnarounds are available for an additional fee when you need it faster." },
  { q: "What kind of clients do you work with?", a: "We primarily partner with B2B businesses, but we're open to working with any brand looking to elevate their marketing image with cinematic, story-driven video." },
  { q: "How far do you travel? Do you charge a travel fee?", a: "We travel anywhere in the world to deliver best-in-class service. Projects within 75 miles of the DFW metroplex include travel at no additional cost. Anything beyond is quoted transparently as a travel line item in your proposal." },
  { q: "What's the best way to get started?", a: "Fill out our contact form and we'll schedule a 30-minute discovery call to learn about your brand, your audience, and what you're trying to accomplish. From there we'll put together a tailored proposal." },
];

function FAQItem({ q, a, defaultOpen = false }: { q: string; a: string; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-[#0B1E3D]/12">
      <button className="flex justify-between items-center w-full py-6 gap-5 text-left" onClick={() => setOpen(!open)}>
        <h3 className="text-[17px] font-bold text-[#0B1E3D] leading-snug">{q}</h3>
        <span className={`w-[30px] h-[30px] flex-shrink-0 rounded-full border-[1.5px] border-[#0B1E3D]/20 flex items-center justify-center text-xl text-[#0B1E3D] transition-transform duration-300 font-light ${open ? "rotate-45" : ""}`}>+</span>
      </button>
      <div className={`overflow-hidden transition-all duration-400 ${open ? "max-h-80" : "max-h-0"}`}>
        <p className="pb-6 text-[15px] text-[#0B1E3D]/65 leading-relaxed">{a}</p>
      </div>
    </div>
  );
}

export default function FAQ() {
  return (
    <>
      <section className="bg-[#142040] pt-32 pb-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Frequently Asked</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-2xl mb-5 leading-tight">We're here to answer every question.</h1>
          <p className="text-white/65 text-lg max-w-lg leading-relaxed">Straight answers about how we work, what things cost, and what to expect from start to finish.</p>
        </div>
      </section>
      <section className="bg-[#F5F4F1] py-18 px-6">
        <div className="max-w-[780px] mx-auto">
          {FAQS.map((item, i) => <FAQItem key={i} q={item.q} a={item.a} defaultOpen={i === 0} />)}
          <div className="pt-10 text-center">
            <p className="text-[#0B1E3D]/55 text-base mb-4">Still have questions?</p>
            <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
              Schedule a Discovery Call →
            </Link>
          </div>
        </div>
      </section>
      <CTASection />
    </>
  );
}
