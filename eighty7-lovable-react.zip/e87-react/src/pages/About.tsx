import CTASection from "../components/CTASection";

export default function About() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#142040] pt-32 pb-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">About</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-2xl leading-tight">
            We're real people who care about outcomes, not awards.
          </h1>
        </div>
      </section>

      {/* Mission */}
      <section className="bg-white py-22 px-6">
        <div className="max-w-[1120px] mx-auto grid md:grid-cols-2 gap-16 items-start">
          <div>
            <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Our Mission</p>
            <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl mb-5 leading-tight">Cinematic storytelling that grows trust and authority.</h2>
            <p className="text-[#0B1E3D]/65 text-base leading-relaxed mb-4">Eighty7 Media is the creative partner for founders, CEOs, and CMOs who understand that great video is a business asset, not a line item. We don't do templates. We don't do cookie-cutter. Every project is strategically scoped to serve your specific business objectives.</p>
            <p className="text-[#0B1E3D]/65 text-base leading-relaxed mb-4">Based in McKinney, TX, we work with mid-market and enterprise brands, private equity partners, and ambitious founders who want their story told with the quality it deserves.</p>
            <p className="text-sm text-[#0B1E3D]/45 leading-relaxed mt-2">Eighty7 Media LLC was founded by Ajit Nair in McKinney, Texas, in 2024. We create strategic video for B2B organizations throughout Dallas-Fort Worth and nationwide.</p>
          </div>
          <div>
            <img src="https://eighty7.media/assets/josh-ramsey-DsFRosA_.webp" alt="Eighty7 Media production" className="rounded-md w-full" />
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section className="bg-[#142040] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">How We Work</p>
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            {[
              { num: "01", title: "Strategic", body: "We think before we shoot. Every project starts with a discovery conversation about your audience, the action you want them to take, and how this video fits into the bigger picture of your brand." },
              { num: "02", title: "Cinematic", body: "Cinema-grade cameras, intentional lighting, considered sound, and a colorist's eye in post. We obsess over the details most people never notice, because those details make a brand feel premium." },
              { num: "03", title: "Human", body: "We don't hand you a script and ask you to perform. We have a real conversation, draw out the story that's already there, and capture the moments that feel honest." },
            ].map(({ num, title, body }) => (
              <div key={num} className="p-8">
                <div className="text-[2.5rem] font-black text-white/[0.06] leading-none mb-3">{num}</div>
                <h3 className="text-white font-extrabold text-[1.1rem] mb-2.5">{title}</h3>
                <p className="text-sm text-white/65 leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Who We Work With */}
      <section className="bg-[#F5F4F1] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">Who We Work With</p>
          <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl mb-10 leading-tight">Built for leaders who move markets.</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { title: "Founders & CEOs", body: "Leaders who know their voice is the brand. We help them show up on camera with clarity and conviction, turning hard-won perspective into thought leadership that compounds trust over time." },
              { title: "CMOs & Marketing Leaders", body: "Marketing teams who need video that earns its place in the funnel. We partner on campaigns, brand films, and ongoing content systems that drive pipeline and sharpen category positioning." },
              { title: "PE / Private Equity", body: "Firms telling the story of the platform, the portfolio, and the people behind the thesis. We craft assets for LP updates, portfolio company launches, and exit narratives that signal serious value." },
              { title: "Enterprise Brands", body: "Established brands that can't afford to look anything less than premium. We deliver polished video assets — internal, external, and everything between — that match the caliber of the company on the page." },
            ].map(({ title, body }) => (
              <div key={title} className="bg-white p-7 rounded border border-[#0B1E3D]/[0.08]">
                <h4 className="text-[#0B1E3D] font-extrabold text-base mb-2.5">{title}</h4>
                <p className="text-sm text-[#0B1E3D]/65 leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="bg-white py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">The Team</p>
          <h2 className="text-[#0B1E3D] font-extrabold text-3xl mb-8 leading-tight">The people behind the camera.</h2>
          <div className="flex gap-7 items-start max-w-lg">
            <div className="w-[72px] h-[72px] bg-[#B8892A] rounded-full flex items-center justify-center text-white text-2xl font-black flex-shrink-0">AN</div>
            <div>
              <div className="text-[#0B1E3D] font-extrabold text-xl mb-1">Ajit Nair</div>
              <div className="text-[10px] font-bold tracking-[0.12em] uppercase text-[#B8892A] mb-3">Founder & Creative Director</div>
              <p className="text-[15px] text-[#0B1E3D]/65 leading-relaxed mb-4">Ajit founded Eighty7 Media to give B2B brands video that works as a business asset, not decoration. With 8+ years behind the camera and in the edit, he leads discovery, creative direction, and the interview room.</p>
              <a href="https://www.linkedin.com/company/eighty7-media/" target="_blank" rel="noopener noreferrer" className="text-[12px] font-bold tracking-[0.08em] uppercase text-[#B8892A] border-b border-[#B8892A] pb-0.5">LinkedIn</a>
            </div>
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
