import { Link, useLocation } from "react-router-dom";

const links = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "Work", to: "/work" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

export default function Nav() {
  const { pathname } = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-[#0B1E3D] border-b border-white/[0.06] flex items-center">
      <div className="max-w-[1120px] mx-auto px-6 w-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img
            src="https://eighty7.media/assets/logo-horizontal-FxIUV_rD.png"
            alt="Eighty7 Media"
            className="h-8"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        </Link>

        {/* Links */}
        <ul className="hidden md:flex items-center gap-7">
          {links.map(({ label, to }) => {
            const active = pathname === to;
            return (
              <li key={to}>
                <Link
                  to={to}
                  className={[
                    "text-[11px] font-semibold tracking-[0.08em] uppercase transition-colors pb-0.5 border-b-[1.5px]",
                    active
                      ? "text-white border-[#B8892A]"
                      : "text-white/70 border-transparent hover:text-white hover:border-[#B8892A]",
                  ].join(" ")}
                >
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>

        {/* CTA */}
        <Link
          to="/contact"
          className="bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[11px] font-bold tracking-[0.1em] uppercase px-[18px] py-[9px] rounded transition-colors whitespace-nowrap"
        >
          Start a Project
        </Link>
      </div>
    </nav>
  );
}
