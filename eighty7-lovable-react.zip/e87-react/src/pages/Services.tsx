import { Link } from "react-router-dom";
import CTASection from "../components/CTASection";

const SERVICES = [
  {
    badge: "THE TRUST BUILDER",
    title: "Video Testimonials",
    desc: "Real clients sharing real outcomes. No scripts, no fake energy — just authentic stories that build credibility and close deals.",
    bullets: ["Build instant credibility with prospects", "Shorten sales cycles", "Reusable assets for every funnel stage"],
    img: "work-2-testimonial-BTlnWCDt.webp",
  },
  {
    badge: "THE AUTHORITY BUILDER",
    title: "Executive Interviews",
    desc: "Founder and executive brand content that positions your leadership team as category authorities — built for LinkedIn, your site, and beyond.",
    bullets: ["Position executives as thought leaders", "Generate months of social content", "Attract top-tier partnerships and talent"],
    img: "work-1-executive-B7pM4FkU.webp",
  },
  {
    badge: "THE CONVERSION DRIVER",
    title: "Product Demos & Reviews",
    desc: "Premium product storytelling for B2B launches. We turn complex features into clear, compelling stories that move buyers to act.",
    bullets: ["Simplify complex products for buyers", "Accelerate product adoption", "Support sales teams with visual proof"],
    img: "work-3-event-Dx4knwSK.webp",
  },
  {
    badge: "THE BRAND AMPLIFIER",
    title: "Showcases",
    desc: "High-impact visual showcases that highlight your work, culture, and capabilities. Case study films and brand anthems built to signal premium.",
    bullets: ["Differentiate from competitors", "Attract enterprise clients", "Build brand equity through visual storytelling"],
    img: "work-1-executive-B7pM4FkU.webp",
  },
  {
    badge: "THE EXPERIENCE CAPTURER",
    title: "Corporate Events",
    desc: "Higher-caliber coverage for conferences, summits, and corporate events. Keynotes, interviews, and energy — captured to extend impact far beyond the room.",
    bullets: ["Extend event ROI with lasting content", "Capture keynotes and panels", "Highlight reels for social and sales"],
    img: "work-3-event-Dx4knwSK.webp",
  },
  {
    badge: "THE TEAM ALIGNER",
    title: "Training & Internal Comms",
    desc: "Onboarding, training, and internal communication videos that align teams, scale culture, and turn complex processes into clear lessons.",
    bullets: ["Shorten onboarding and ramp time", "Standardize training across locations", "Strengthen culture and alignment"],
    img: "work-2-testimonial-BTlnWCDt.webp",
  },
];

export default function Services() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#142040] pt-32 pb-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Services</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-2xl mb-5 leading-tight">
            Strategic video for every stage of growth.
          </h1>
          <p className="text-white/65 text-lg max-w-lg leading-relaxed">
            Every project is custom-scoped to your business objectives. No packages, just strategic partnerships built on outcomes.
          </p>
        </div>
      </section>

      {/* Service blocks */}
      {SERVICES.map(({ badge, title, desc, bullets, img }, i) => (
        <div key={title} className={`py-18 px-6 border-b border-white/[0.07] ${i % 2 === 1 ? "bg-[#142040]" : "bg-[#0B1E3D]"}`}>
          <div className="max-w-[1120px] mx-auto">
            <div className={`grid md:grid-cols-2 gap-16 items-center ${i % 2 === 1 ? "md:[&>:first-child]:order-2" : ""}`}>
              <div>
                {/* Badge */}
                <div className="inline-flex items-center gap-2 bg-[#B8892A]/15 border border-[#B8892A]/30 rounded-full px-3.5 py-1.5 mb-5">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#B8892A" strokeWidth="2"><circle cx="12" cy="12" r="10" /><polygon points="10 8 16 12 10 16" fill="#B8892A" stroke="none" /></svg>
                  <span className="text-[10px] font-bold tracking-[0.12em] uppercase text-[#B8892A]">{badge}</span>
                </div>
                <h2 className="text-white font-extrabold text-3xl md:text-4xl mb-4 leading-tight">{title}</h2>
                <p className="text-white/65 text-base leading-relaxed mb-6">{desc}</p>
                <ul className="space-y-0 border-t border-white/[0.07]">
                  {bullets.map((b) => (
                    <li key={b} className="flex items-center gap-2.5 text-sm text-white/65 py-[7px] border-b border-white/[0.07]">
                      <span className="text-[#B8892A] font-bold flex-shrink-0">—</span>
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-md overflow-hidden aspect-[4/3]">
                <img src={`https://eighty7.media/assets/${img}`} alt={title} className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Bottom CTA */}
      <section className="bg-[#0B1E3D] py-20 px-6 text-center">
        <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Every project starts with a conversation.</p>
        <h2 className="text-white font-extrabold text-3xl md:text-5xl mb-4 leading-tight">Tell us about your project.</h2>
        <p className="text-white/65 text-base max-w-lg mx-auto mb-8 leading-relaxed">We'll schedule a discovery call to understand your goals and put together a tailored proposal.</p>
        <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
          Start Your Project →
        </Link>
        <div className="mt-6 flex gap-2 justify-center items-center text-sm text-white/45 flex-wrap">
          <span>See examples in our</span>
          <Link to="/work" className="text-[#B8892A] border-b border-[#B8892A]">work</Link>
          <span>or browse</span>
          <Link to="/faq" className="text-[#B8892A] border-b border-[#B8892A]">frequently asked questions</Link>
        </div>
      </section>
    </>
  );
}
