# Eighty7 Media — React Source for Lovable

This is the complete React + TypeScript + Tailwind source code for eighty7.media.
Upload this to Lovable by importing the zip into your project.

## What's included

- `src/App.tsx` — Root app with React Router setup (7 routes)
- `src/components/Nav.tsx` — Fixed top navigation
- `src/components/Footer.tsx` — 3-column footer
- `src/components/CTASection.tsx` — Gold CTA block used on all pages
- `src/pages/Home.tsx` — Full home page (hero, logos, work tiles, services, process, why, FAQ)
- `src/pages/Services.tsx` — 6 service blocks alternating left/right
- `src/pages/Work.tsx` — 2-column dark card grid
- `src/pages/About.tsx` — Mission, pillars, who we work with, team
- `src/pages/Contact.tsx` — Split layout, interactive chip checkboxes
- `src/pages/FAQ.tsx` — Accordion FAQ
- `src/pages/McKinney.tsx` — Local SEO page

## How to use in Lovable

**Option 1 — Paste into Lovable chat:**
Copy the contents of individual files and paste them into Lovable with the prompt:
"Replace [filename] with this exact code"

**Option 2 — GitHub import:**
1. Create a new repo and push this folder
2. In Lovable, connect the repo under Settings → GitHub

**Option 3 — Direct file upload:**
In Lovable, open the file editor and replace each file's contents directly.

## Design tokens (used consistently throughout)

| Token         | Value     |
|---------------|-----------|
| Navy (bg)     | #0B1E3D   |
| Navy alt      | #142040   |
| Gold          | #B8892A   |
| Gold hover    | #D4AA44   |
| Light bg      | #F5F4F1   |
| Font          | Inter     |

## Social links
- LinkedIn: https://www.linkedin.com/company/eighty7-media/
- Instagram: https://www.instagram.com/eighty7_media
