import { Link } from "react-router-dom";

function LinkedInIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="2" width="20" height="20" rx="4" />
      <line x1="8" y1="11" x2="8" y2="16" />
      <line x1="8" y1="7.5" x2="8" y2="8.5" strokeWidth="3" />
      <line x1="12" y1="11" x2="12" y2="16" />
      <path d="M12 13c0-1.5 1-2 2-2s2 .5 2 2v3" />
    </svg>
  );
}

function InstagramIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="2" width="20" height="20" rx="5" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export default function Footer() {
  return (
    <footer className="bg-[#0B1E3D] border-t border-white/[0.08] pt-16 pb-8">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-[1.6fr_1fr_1fr] gap-12 mb-12">
          {/* Brand */}
          <div>
            <Link to="/" className="block mb-3">
              <img
                src="https://eighty7.media/assets/logo-horizontal-FxIUV_rD.png"
                alt="Eighty7 Media"
                className="h-7"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
            </Link>
            <p className="text-sm text-white/50 leading-relaxed mb-5 max-w-[260px]">
              Cinematic storytelling for B2B leaders who understand that great video is a business asset.
            </p>
            <div className="flex gap-3">
              <a
                href="https://www.linkedin.com/company/eighty7-media/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-[34px] h-[34px] rounded border border-white/15 flex items-center justify-center text-white/55 hover:text-[#B8892A] hover:border-[#B8892A] transition-colors"
                aria-label="LinkedIn"
              >
                <LinkedInIcon />
              </a>
              <a
                href="https://www.instagram.com/eighty7_media"
                target="_blank"
                rel="noopener noreferrer"
                className="w-[34px] h-[34px] rounded border border-white/15 flex items-center justify-center text-white/55 hover:text-[#B8892A] hover:border-[#B8892A] transition-colors"
                aria-label="Instagram"
              >
                <InstagramIcon />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h5 className="text-[10px] font-bold tracking-[0.15em] uppercase text-white/35 mb-4">Navigation</h5>
            <ul className="space-y-2.5">
              {[
                { label: "Services", to: "/services" },
                { label: "Work", to: "/work" },
                { label: "About Eighty7 Media", to: "/about" },
                { label: "McKinney Video Production", to: "/mckinney" },
                { label: "FAQ", to: "/faq" },
                { label: "Contact", to: "/contact" },
              ].map(({ label, to }) => (
                <li key={to}>
                  <Link to={to} className="text-sm text-white/55 hover:text-[#B8892A] transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h5 className="text-[10px] font-bold tracking-[0.15em] uppercase text-white/35 mb-4">Get in Touch</h5>
            <p className="text-sm text-white/55 leading-relaxed">
              <span className="text-white/80 font-semibold">Eighty7 Media LLC</span>
              <br />McKinney, Texas
              <br />
              <a href="mailto:info@eighty7.media" className="hover:text-[#B8892A] transition-colors">
                info@eighty7.media
              </a>
              <br />Serving DFW &amp; Nationwide
            </p>
          </div>
        </div>

        <div className="border-t border-white/[0.07] pt-5 flex justify-between items-center text-[12px] text-white/30">
          <span>© 2026 Eighty7 Media. All rights reserved.</span>
          <span>McKinney, TX</span>
        </div>
      </div>
    </footer>
  );
}
