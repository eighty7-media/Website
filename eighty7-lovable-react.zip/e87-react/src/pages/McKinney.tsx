import { Link } from "react-router-dom";
import CTASection from "../components/CTASection";

export default function McKinney() {
  return (
    <>
      <section className="bg-[#142040] pt-32 pb-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <span className="inline-flex items-center gap-2 bg-[#B8892A]/15 border border-[#B8892A]/30 rounded-full px-3.5 py-1.5 text-[12px] font-semibold text-[#B8892A] mb-5">📍 McKinney, Texas</span>
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">B2B Video Production</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-3xl mb-5 leading-tight">McKinney Video Production for B2B Brands</h1>
          <p className="text-white/65 text-lg max-w-xl leading-relaxed mb-7">Eighty7 Media is McKinney's premier B2B video production company. We serve the greater DFW area and work with growing companies across Texas and nationwide.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
            Book a Discovery Call →
          </Link>
        </div>
      </section>

      <section className="bg-white py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">Who We Serve</p>
          <h2 className="text-[#0B1E3D] font-extrabold text-3xl md:text-4xl mb-3 leading-tight">McKinney and DFW's B2B video studio.</h2>
          <p className="text-[#0B1E3D]/65 text-base max-w-xl mb-10 leading-relaxed">We work with B2B companies of all sizes — from McKinney startups to Fortune 500 enterprises headquartered in the DFW corridor.</p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: "B2B SaaS & Technology", desc: "Product demos, customer success stories, and executive thought leadership for software companies competing in crowded markets." },
              { title: "Professional Services", desc: "Law firms, accounting firms, consultancies, and agencies that need to build trust with premium video content before the first meeting." },
              { title: "Enterprise & Mid-Market", desc: "Corporate communications, internal training, and brand storytelling for growing companies that need content at scale." },
            ].map(({ title, desc }) => (
              <div key={title} className="p-7 border border-[#0B1E3D]/10 rounded">
                <h3 className="text-[#0B1E3D] font-extrabold text-base mb-2.5">{title}</h3>
                <p className="text-sm text-[#0B1E3D]/65 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#142040] py-22 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-3">What We Produce</p>
          <h2 className="text-white font-extrabold text-3xl md:text-4xl mb-8 leading-tight">Video that moves the needle for DFW businesses.</h2>
          <ul className="border-t border-white/[0.08]">
            {[
              { n: "01", title: "Customer Testimonial Videos", desc: "Real stories from real clients — shot in McKinney, Frisco, Plano, and across DFW." },
              { n: "02", title: "Executive Interview Series", desc: "Thought leadership content for founders and C-suite leaders building their personal brand." },
              { n: "03", title: "Brand Films & Showcases", desc: "Cinematic company stories for websites, investor decks, and trade show screens." },
              { n: "04", title: "Event & Conference Coverage", desc: "Multi-camera coverage for corporate events, summits, and product launches across the Metroplex." },
            ].map(({ n, title, desc }) => (
              <li key={n} className="grid grid-cols-[32px_1fr] gap-4 py-5 border-b border-white/[0.08] items-start">
                <span className="text-[11px] font-bold text-[#B8892A] tracking-[0.05em] pt-1">{n}</span>
                <div>
                  <h4 className="text-white font-extrabold text-[15px] mb-1">{title}</h4>
                  <p className="text-sm text-white/65 leading-relaxed">{desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <CTASection />
    </>
  );
}
