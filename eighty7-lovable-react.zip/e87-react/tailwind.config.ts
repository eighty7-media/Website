import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: "#0B1E3D",
          50: "#F0F4FA",
          100: "#142040",
          200: "#1a2d55",
          300: "#0B1E3D",
        },
        gold: {
          DEFAULT: "#B8892A",
          light: "#D4AA44",
          dim: "rgba(184,137,42,0.15)",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      maxWidth: {
        site: "1120px",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
