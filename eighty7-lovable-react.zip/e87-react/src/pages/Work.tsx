import { Link } from "react-router-dom";
import CTASection from "../components/CTASection";

const WORK_CARDS = [
  { tag: "CUSTOMER STORIES", title: "Testimonials & success features", desc: "Customer testimonial and success-story films for B2B brands. We interview real clients about the problem they faced, the decision they made, and the measurable outcome — then cut a hero film plus short sales and social versions from the same session." },
  { tag: "EXECUTIVE PRESENCE", title: "Thought leadership & interviews", desc: "Executive interviews and thought-leadership series for founders, CEOs, and subject-matter experts. Studio or on-location setups designed to make leaders sound credible and look premium — delivered as long-form episodes and LinkedIn-ready clips." },
  { tag: "BRAND & CULTURE", title: "Company narrative films", desc: "Brand and culture narrative films that explain who a company is, who it serves, and why it exists. Used on homepages, in recruiting, and at the top of the funnel where a buyer decides whether a brand feels serious." },
  { tag: "PRODUCT & DEMO", title: "Cinematic product storytelling", desc: "Cinematic product films and demos for B2B launches. We translate technical capability into a clear visual story so prospects understand what the product does and why it matters, with cutdowns for ads, email, and sales decks." },
  { tag: "EVENTS & KEYNOTES", title: "Higher-caliber event coverage", desc: "Conference, summit, and keynote coverage with multi-camera capture and clean audio. Deliverables include speaker session edits, sizzle reels, and vertical highlights for post-event promotion." },
  { tag: "INTERNAL & TRAINING", title: "Onboarding & internal comms", desc: "Onboarding, training, and internal communication video for teams that need consistency at scale. Modular lessons and leadership messages that shorten ramp time and keep distributed teams aligned." },
];

export default function Work() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#142040] pt-32 pb-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Our Work</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-2xl mb-5 leading-tight">
            Cinematic storytelling that earns its reputation.
          </h1>
          <p className="text-white/65 text-lg max-w-xl leading-relaxed">
            Every project is a partnership. Below are the bodies of work we produce most often for B2B leaders — each one custom-scoped to the audience, format, and outcome that matters most.
          </p>
        </div>
      </section>

      {/* Grid */}
      <section className="bg-[#0B1E3D] py-18 px-6">
        <div className="max-w-[1120px] mx-auto">
          <div className="grid md:grid-cols-2 gap-4 mb-16">
            {WORK_CARDS.map(({ tag, title, desc }) => (
              <div key={tag} className="bg-[#142040] border border-white/[0.06] rounded-md p-8">
                <p className="text-[10px] font-bold tracking-[0.12em] uppercase text-[#B8892A] mb-3">{tag}</p>
                <h2 className="text-white font-extrabold text-2xl md:text-3xl mb-4 leading-tight">{title}</h2>
                <p className="text-white/65 text-[15px] leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom */}
      <section className="bg-[#142040] py-18 px-6 text-center">
        <div className="max-w-[1120px] mx-auto">
          <h2 className="text-white font-extrabold text-3xl md:text-5xl mb-4 leading-tight">Ready to create your own success story?</h2>
          <p className="text-white/65 text-base max-w-lg mx-auto mb-8 leading-relaxed">Browse the full services lineup, read common questions, or get in touch directly.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-[#B8892A] hover:bg-[#D4AA44] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-6 py-3.5 rounded transition-colors">
            Start Your Project →
          </Link>
        </div>
      </section>
    </>
  );
}
