import { useState } from "react";

const SERVICES_OPTIONS = [
  "Video Testimonials",
  "Executive Interviews",
  "Product Demos & Reviews",
  "Showcases",
  "Corporate Events",
  "Training & Internal Communications",
  "Not Sure Yet",
];

export default function Contact() {
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (s: string) =>
    setSelected((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]);

  return (
    <>
      {/* Hero */}
      <section className="bg-[#142040] pt-32 pb-16 px-6">
        <div className="max-w-[1120px] mx-auto">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-[#B8892A] mb-4">Start a Project</p>
          <h1 className="text-white font-extrabold text-4xl md:text-5xl max-w-2xl mb-4 leading-tight">Tell us about your vision.</h1>
          <p className="text-white/65 text-lg max-w-lg leading-relaxed">Every project starts with a conversation. Share your goals and we'll schedule a discovery call to scope the engagement.</p>
        </div>
      </section>

      {/* Form section */}
      <section className="bg-[#F5F4F1] py-18 px-6">
        <div className="max-w-[1120px] mx-auto grid md:grid-cols-[220px_1fr] gap-16 items-start">
          {/* Info */}
          <div>
            <h2 className="text-[#0B1E3D] font-extrabold text-xl mb-6 leading-snug">Let's build something worth watching.</h2>
            <div className="space-y-6">
              {[
                { label: "Email", val: <a href="mailto:info@eighty7.media" className="text-[#B8892A]">info@eighty7.media</a> },
                { label: "Studio", val: <span>McKinney, TX<br />Serving DFW & Nationwide</span> },
                { label: "Hours", val: <span>Mon – Sat · 8a – 8p CT</span> },
              ].map(({ label, val }) => (
                <div key={label}>
                  <p className="text-[10px] font-bold tracking-[0.12em] uppercase text-[#B8892A] mb-1.5">{label}</p>
                  <p className="text-sm text-[#0B1E3D]/65 leading-relaxed">{val}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <form className="space-y-0" onSubmit={(e) => e.preventDefault()}>
            <div className="grid md:grid-cols-2 gap-4 mb-5">
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Full Name *</label>
                <input type="text" required placeholder="Your name" className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors" />
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Email *</label>
                <input type="email" required placeholder="you@company.com" className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors" />
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4 mb-5">
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Company</label>
                <input type="text" placeholder="Company name" className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors" />
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Role / Title</label>
                <input type="text" placeholder="CEO, CMO, Marketing Director..." className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors" />
              </div>
            </div>

            {/* Service chips */}
            <div className="mb-5">
              <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-2.5">Services You're Interested In *</label>
              <div className="flex flex-wrap gap-2">
                {SERVICES_OPTIONS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggle(s)}
                    className={[
                      "px-3.5 py-2 rounded text-[13px] font-semibold border-[1.5px] transition-colors",
                      selected.includes(s)
                        ? "bg-[#0B1E3D] border-[#0B1E3D] text-white"
                        : "bg-white border-[#0B1E3D]/15 text-[#0B1E3D] hover:border-[#0B1E3D]/40",
                    ].join(" ")}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-5">
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Budget Range</label>
                <select className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors appearance-none">
                  <option value="">Select a range</option>
                  <option>Under $5,000</option>
                  <option>$5,000 – $15,000</option>
                  <option>$15,000 – $30,000</option>
                  <option>$30,000 – $75,000</option>
                  <option>$75,000+</option>
                  <option>Not sure yet</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Timeline</label>
                <select className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors appearance-none">
                  <option value="">Select a timeline</option>
                  <option>ASAP (within 2 weeks)</option>
                  <option>1–2 months</option>
                  <option>2–3 months</option>
                  <option>3+ months</option>
                  <option>Flexible</option>
                </select>
              </div>
            </div>

            <div className="mb-7">
              <label className="block text-[11px] font-bold tracking-[0.08em] uppercase text-[#0B1E3D]/60 mb-1.5">Project Description *</label>
              <textarea required placeholder="Tell us about your project goals, target audience, deliverables needed, and any specific requirements..." className="w-full px-3.5 py-3 border-[1.5px] border-[#0B1E3D]/15 rounded text-[#0B1E3D] text-[15px] bg-white focus:outline-none focus:border-[#0B1E3D] transition-colors resize-y min-h-[120px]" />
            </div>

            <button type="submit" className="w-full py-3.5 bg-[#0B1E3D] hover:bg-[#142040] text-white font-bold text-[14px] tracking-[0.05em] uppercase rounded transition-colors">
              Send Message →
            </button>
          </form>
        </div>
      </section>
    </>
  );
}
