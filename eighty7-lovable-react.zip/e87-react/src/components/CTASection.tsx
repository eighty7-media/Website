import { Link } from "react-router-dom";

export default function CTASection() {
  return (
    <section className="bg-[#B8892A] py-20 px-6 text-center">
      <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-white/65 mb-4">
        Ready to Start?
      </p>
      <h2 className="text-white font-extrabold text-3xl md:text-5xl leading-tight mb-7">
        Let's create something<br />worth watching.
      </h2>
      <Link
        to="/contact"
        className="inline-flex items-center gap-2 bg-[#0B1E3D] hover:bg-[#142040] text-white text-[13px] font-bold tracking-[0.05em] uppercase px-7 py-3.5 rounded transition-colors"
      >
        Start Your Project →
      </Link>
    </section>
  );
}
